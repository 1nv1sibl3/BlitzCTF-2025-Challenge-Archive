#!/bin/bash

# Start cron for clearing /tmp
service cron start

# Start SSH
/usr/sbin/sshd -D