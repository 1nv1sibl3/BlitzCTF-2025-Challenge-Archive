// You can extend this file if you want additional behaviors.
// For now, generate-coupon logic is embedded inline on dashboard.
console.log("Static JS loaded.");
