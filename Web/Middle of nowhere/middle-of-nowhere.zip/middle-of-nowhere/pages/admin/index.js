import React from "react";
import { useRouter } from "next/router";
import { deleteCookie } from "cookies-next";

export default function Admin() {
  const router = useRouter();

  const handleLogout = () => {
    deleteCookie("auth");
    router.push("/login");
  };

  const containerStyle = {
    backgroundColor: "#000",
    color: "#0f0",
    fontFamily: "Courier New, monospace",
    minHeight: "100vh",
    padding: "2rem",
  };

  const headerStyle = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "2rem",
  };

  const titleStyle = {
    fontSize: "2.5rem",
  };

  const buttonStyle = {
    backgroundColor: "#0f0",
    color: "#000",
    padding: "0.5rem 1rem",
    border: "2px solid #0f0",
    borderRadius: "4px",
    cursor: "pointer",
    fontWeight: "bold",
  };

  const cardStyle = {
    backgroundColor: "#111",
    padding: "1.5rem",
    borderRadius: "8px",
    boxShadow: "0 0 10px #0f0",
    marginBottom: "1rem",
  };

  const flagStyle = {
    fontFamily: "monospace",
    backgroundColor: "#222",
    padding: "0.5rem",
    borderRadius: "4px",
    display: "inline-block",
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1 style={titleStyle}>Admin Dashboard</h1>
        <button style={buttonStyle} onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div style={cardStyle}>
        <h2>Welcome to the Admin Dashboard of BlitzHack</h2>
        <p>
          You are logged in as: <strong style={{ color: "#0f0" }}>admin</strong>
        </p>
      </div>

      <div style={cardStyle}>
        <h2>Flag</h2>
        <p style={flagStyle}> {"Blitz{N3x7js_M1ddl3w4r3_Byyyyp4sssssss}"}</p>
      </div>
      <div
        style={{
          marginTop: "2rem",
          textAlign: "center",
          fontSize: "0.85rem",
          color: "#00ff00",
          textShadow: "0 0 5px #00ff00",
          opacity: 0.8,
        }}
      >
        <span style={{ fontStyle: "italic" }}>
          made with <span style={{ color: "#f00" }}>♥</span> by{" "}
          <strong>@rahisec</strong>
        </span>
      </div>
    </div>
  );
}
