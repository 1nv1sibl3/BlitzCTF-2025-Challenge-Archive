import { useState } from "react";
import { useRouter } from "next/router";
import { setCookie } from "cookies-next";

export default function Login() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const formData = new FormData(e.target);
    const username = formData.get("username");
    const password = formData.get("password");

    // Hardcoded admin credentials | no one should guess the username and password | should be changed to redacted if the source code is provided.
    if (username === "adm1n" && password === "BlitZ123Hackzzzzzzzz") {
      setCookie("auth", "BlitZHackzzzzzzzz", { maxAge: 60 * 60 }); // 1 hour expiry | for this challenge source code will not provided. so, no one can guess the cookie. | or if provided this should be changed to redacted.
      router.push("/admin");
    } else {
      setError("Invalid credentials");
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        height: "100vh",
        backgroundColor: "#000",
        color: "#00ff00",
        fontFamily: "monospace",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        overflow: "hidden",
        position: "relative",
      }}
    >
      {/* Matrix lines */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background:
            "radial-gradient(ellipse at center, rgba(0,255,0,0.1) 0%, transparent 100%)",
          zIndex: 0,
          animation: "pulse 5s infinite alternate",
        }}
      />

      <div
        style={{
          zIndex: 1,
          padding: "2rem",
          border: "1px solid #00ff00",
          borderRadius: "8px",
          boxShadow: "0 0 20px #00ff00",
          width: "100%",
          maxWidth: "400px",
          backgroundColor: "rgba(0,0,0,0.8)",
        }}
      >
        <h1
          style={{
            textAlign: "center",
            marginBottom: "2rem",
            fontSize: "1.5rem",
            textShadow: "0 0 10px #00ff00",
          }}
        >
          BlitzHack Access Console
        </h1>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <label>Username:</label>
            <input
              type="text"
              name="username"
              required
              style={{
                width: "100%",
                padding: "0.5rem",
                backgroundColor: "#111",
                color: "#0f0",
                border: "1px solid #0f0",
                borderRadius: "4px",
                outline: "none",
              }}
            />
          </div>
          <div style={{ marginBottom: "1rem" }}>
            <label>Password:</label>
            <input
              type="password"
              name="password"
              required
              style={{
                width: "100%",
                padding: "0.5rem",
                backgroundColor: "#111",
                color: "#0f0",
                border: "1px solid #0f0",
                borderRadius: "4px",
                outline: "none",
              }}
            />
          </div>
          {error && (
            <div style={{ color: "red", marginBottom: "1rem" }}>{error}</div>
          )}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: "100%",
              padding: "0.75rem",
              backgroundColor: "#000",
              color: "#0f0",
              border: "1px solid #0f0",
              borderRadius: "4px",
              cursor: loading ? "not-allowed" : "pointer",
              textShadow: "0 0 5px #0f0",
              transition: "all 0.3s",
              opacity: loading ? 0.5 : 1,
            }}
          >
            {loading ? "Decrypting..." : "Enter"}
          </button>
        </form>
        <div
          style={{
            marginTop: "2rem",
            textAlign: "center",
            fontSize: "0.85rem",
            color: "#00ff00",
            textShadow: "0 0 5px #00ff00",
            opacity: 0.8,
          }}
        >
          <span style={{ fontStyle: "italic" }}>
            made with <span style={{ color: "#f00" }}>♥</span> by{" "}
            <strong>@rahisec</strong>
          </span>
        </div>
      </div>

      {/* Simple background animation */}
      <style jsx global>{`
        @keyframes pulse {
          from {
            transform: scale(1);
            opacity: 0.6;
          }
          to {
            transform: scale(1.2);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
