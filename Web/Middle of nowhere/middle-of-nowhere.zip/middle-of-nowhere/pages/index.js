import React from "react";
import { useRouter } from "next/router";

export default function Home() {
  const router = useRouter();

  const containerStyle = {
    backgroundColor: "#000",
    color: "#0f0",
    fontFamily: "Courier New, monospace",
    minHeight: "90vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "2rem",
  };

  const titleStyle = {
    fontSize: "3rem",
    marginBottom: "1rem",
    textShadow: "0 0 10px #0f0",
  };

  const subtitleStyle = {
    fontSize: "1.25rem",
    marginBottom: "2rem",
    maxWidth: "600px",
    textAlign: "center",
    lineHeight: "1.5",
  };

  const buttonStyle = {
    backgroundColor: "#000",
    color: "#0f0",
    border: "2px solid #0f0",
    padding: "0.75rem 1.5rem",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "1rem",
    textShadow: "0 0 5px #0f0",
    transition: "background-color 0.2s, color 0.2s",
  };

  const footerStyle = {
    marginTop: "auto",
    textAlign: "center",
    fontSize: "0.85rem",
    color: "#00ff00",
    textShadow: "0 0 5px #00ff00",
    opacity: 0.8,
  };

  return (
    <div style={containerStyle}>
      <h1 style={titleStyle}>Welcome Warriors</h1>
      <p style={subtitleStyle}>Are you lost in the Middle of nowhere?</p>
      <button
        style={buttonStyle}
        onMouseOver={(e) => {
          e.target.style.backgroundColor = "#0f0";
          e.target.style.color = "#000";
        }}
        onMouseOut={(e) => {
          e.target.style.backgroundColor = "#000";
          e.target.style.color = "#0f0";
        }}
        onClick={() => router.push("/admin")}
      >
        Follow My Lead
      </button>

      <div style={footerStyle}>
        <span style={{ fontStyle: "italic" }}>
          made with <span style={{ color: "#f00" }}>♥</span> by{" "}
          <strong>@rahisec</strong>
        </span>
      </div>
    </div>
  );
}
