from flask import Flask, render_template, request, redirect, session
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import sqlite3
import uuid
import os
import hashlib
import random

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', str(uuid.uuid4()))

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["100 per day", "25 per hour"],
    storage_uri="memory://"
)

DB_PATH = os.path.join(os.getcwd(), 'users.db')
ADMIN_ID = -3
ADMIN_PASS = os.environ.get('ADMIN_PASS', 'Shadowh2501')

def init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)''')
        admin_pw_hash = hashlib.md5(ADMIN_PASS.encode()).hexdigest()
        c.execute("INSERT OR IGNORE INTO users VALUES (?, 'admin', ?)", (ADMIN_ID, admin_pw_hash))
        conn.commit()
        print(f"Database initialized. Admin ID: {ADMIN_ID}")
    except Exception as e:
        print(f"Database initialization error: {str(e)}")
    finally:
        conn.close()

init_db()

@app.route('/')
def index():
    return redirect('/login')

@app.route('/register', methods=['GET', 'POST'])
@limiter.limit("5 per minute")
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.md5(password.encode()).hexdigest()
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            user_id = None
            for _ in range(10):
                candidate_id = random.randint(2, 100000)
                c.execute("SELECT 1 FROM users WHERE id=?", (candidate_id,))
                if not c.fetchone():
                    user_id = candidate_id
                    break
            if not user_id:
                return render_template('register.html', error="Registration failed. Try again.")
            c.execute("INSERT INTO users (id, username, password) VALUES (?, ?, ?)", (user_id, username, password_hash))
            conn.commit()
            return redirect('/login')
        except sqlite3.IntegrityError:
            return render_template('register.html', error="Username already exists!")
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5 per minute")
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.md5(password.encode()).hexdigest()
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id FROM users WHERE username=? AND password=?", (username, password_hash))
        user_id = c.fetchone()
        conn.close()
        if user_id:
            session['user_id'] = user_id[0]
            return redirect(f'/profile?id={user_id[0]}')
        else:
            return render_template('login.html', error="Invalid credentials!")
    return render_template('login.html')

@app.route('/profile')
@limiter.limit("10 per minute")
def profile():
    if 'user_id' not in session:
        return redirect('/login')
    user_id = request.args.get('id')
    if not user_id:
        return "Missing user ID", 400
    try:
        user_id_int = int(user_id)
        if user_id_int < 0 and user_id_int != ADMIN_ID:
            return "User not found", 404
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE id=?", (user_id_int,))
        user = c.fetchone()
        if user:
            return render_template('profile.html',
                                   username=user[1],
                                   user_id=user[0],
                                   flag="Blitz{ID0R_1s_FUN_w1TH_N3g4t1v3_IDs!?}" if user[0] == ADMIN_ID else None)
        return "User not found", 404
    except ValueError:
        return "Invalid user ID", 400
    finally:
        conn.close()

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
